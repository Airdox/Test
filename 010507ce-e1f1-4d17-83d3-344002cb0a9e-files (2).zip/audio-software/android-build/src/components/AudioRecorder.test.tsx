import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { screen, waitFor, fireEvent } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { render } from '../test/utils'
import { mockMediaDevices } from '../test/test-data'

// Mock AudioRecorder component (since it's part of the main App)
const MockAudioRecorder = ({ onRecordingComplete }: { onRecordingComplete: (recording: any) => void }) => {
  const [isRecording, setIsRecording] = React.useState(false)
  const [recordingTime, setRecordingTime] = React.useState(0)

  const startRecording = () => {
    setIsRecording(true)
    setRecordingTime(0)
    
    // Simulate recording timer
    const interval = setInterval(() => {
      setRecordingTime(prev => prev + 1)
    }, 1000)
    
    // Simulate recording completion after 3 seconds
    setTimeout(() => {
      clearInterval(interval)
      setIsRecording(false)
      setRecordingTime(0)
      onRecordingComplete({
        id: 'test-recording',
        name: 'Test Recording',
        blob: new Blob(['audio-data'], { type: 'audio/wav' }),
        duration: 3,
        createdAt: new Date(),
        url: 'mock-url'
      })
    }, 3000)
  }

  const stopRecording = () => {
    setIsRecording(false)
    setRecordingTime(0)
  }

  return (
    <div data-testid="audio-recorder">
      <button
        onClick={isRecording ? stopRecording : startRecording}
        data-testid="record-button"
      >
        {isRecording ? 'Stop Recording' : 'Start Recording'}
      </button>
      {isRecording && (
        <div data-testid="recording-status">
          Recording: {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}
        </div>
      )}
    </div>
  )
}

// Mock navigator.mediaDevices
Object.defineProperty(navigator, 'mediaDevices', {
  writable: true,
  value: mockMediaDevices
})

describe('AudioRecorder Component', () => {
  let mockOnRecordingComplete: ReturnType<typeof vi.fn>

  beforeEach(() => {
    vi.clearAllMocks()
    mockOnRecordingComplete = vi.fn()
    
    // Reset MediaRecorder mock
    global.MediaRecorder = vi.fn().mockImplementation(() => ({
      start: vi.fn(),
      stop: vi.fn(),
      pause: vi.fn(),
      resume: vi.fn(),
      requestData: vi.fn(),
      state: 'inactive',
      ondataavailable: null,
      onstop: null,
      onerror: null,
      onstart: null,
      onpause: null,
      onresume: null,
      mimeType: 'audio/webm'
    }))
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  describe('Initial State', () => {
    it('renders record button in initial state', () => {
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      expect(recordButton).toBeInTheDocument()
      expect(recordButton).toHaveTextContent('Start Recording')
    })

    it('does not show recording status initially', () => {
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      expect(screen.queryByTestId('recording-status')).not.toBeInTheDocument()
    })
  })

  describe('Recording Process', () => {
    it('starts recording when button is clicked', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      await user.click(recordButton)
      
      expect(recordButton).toHaveTextContent('Stop Recording')
      expect(screen.getByTestId('recording-status')).toBeInTheDocument()
    })

    it('displays recording timer', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      await user.click(recordButton)
      
      const status = screen.getByTestId('recording-status')
      expect(status).toHaveTextContent('Recording: 0:00')
      
      // Wait for timer to update
      await waitFor(() => {
        expect(status).toHaveTextContent('Recording: 0:01')
      }, { timeout: 2000 })
    })

    it('stops recording when stop button is clicked', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      // Start recording
      const recordButton = screen.getByTestId('record-button')
      await user.click(recordButton)
      
      expect(recordButton).toHaveTextContent('Stop Recording')
      
      // Stop recording
      await user.click(recordButton)
      
      expect(recordButton).toHaveTextContent('Start Recording')
      expect(screen.queryByTestId('recording-status')).not.toBeInTheDocument()
    })

    it('completes recording automatically after timeout', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      await user.click(recordButton)
      
      // Wait for automatic completion
      await waitFor(() => {
        expect(mockOnRecordingComplete).toHaveBeenCalledWith(
          expect.objectContaining({
            id: 'test-recording',
            name: 'Test Recording',
            duration: 3
          })
        )
      }, { timeout: 4000 })
      
      expect(recordButton).toHaveTextContent('Start Recording')
    })
  })

  describe('MediaRecorder Integration', () => {
    it('requests microphone access', async () => {
      const user = userEvent.setup()
      
      // Create a more realistic test with actual MediaRecorder logic
      const TestComponent = () => {
        const [isRecording, setIsRecording] = React.useState(false)
        
        const startRecording = async () => {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
            const recorder = new MediaRecorder(stream)
            setIsRecording(true)
          } catch (error) {
            console.error('Microphone access denied:', error)
          }
        }
        
        return (
          <button onClick={startRecording} data-testid="real-record-button">
            {isRecording ? 'Recording...' : 'Start Recording'}
          </button>
        )
      }
      
      render(<TestComponent />)
      
      const recordButton = screen.getByTestId('real-record-button')
      await user.click(recordButton)
      
      expect(mockMediaDevices.getUserMedia).toHaveBeenCalledWith({ audio: true })
    })

    it('handles microphone access denial', async () => {
      const user = userEvent.setup()
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
      
      // Mock getUserMedia to reject
      mockMediaDevices.getUserMedia.mockRejectedValueOnce(new Error('Permission denied'))
      
      const TestComponent = () => {
        const [error, setError] = React.useState<string | null>(null)
        
        const startRecording = async () => {
          try {
            await navigator.mediaDevices.getUserMedia({ audio: true })
          } catch (error) {
            setError('Microphone access denied')
            console.error('Microphone access denied:', error)
          }
        }
        
        return (
          <div>
            <button onClick={startRecording} data-testid="record-button-with-error">
              Start Recording
            </button>
            {error && <div data-testid="error-message">{error}</div>}
          </div>
        )
      }
      
      render(<TestComponent />)
      
      const recordButton = screen.getByTestId('record-button-with-error')
      await user.click(recordButton)
      
      await waitFor(() => {
        expect(screen.getByTestId('error-message')).toHaveTextContent('Microphone access denied')
      })
      
      expect(consoleErrorSpy).toHaveBeenCalledWith(
        'Microphone access denied:',
        expect.any(Error)
      )
      
      consoleErrorSpy.mockRestore()
    })
  })

  describe('Audio Quality', () => {
    it('uses appropriate audio settings', async () => {
      const user = userEvent.setup()
      
      const TestComponent = () => {
        const startRecording = async () => {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: {
              sampleRate: 44100,
              channelCount: 1,
              echoCancellation: true,
              noiseSuppression: true
            }
          })
        }
        
        return (
          <button onClick={startRecording} data-testid="quality-record-button">
            Start Recording
          </button>
        )
      }
      
      render(<TestComponent />)
      
      const recordButton = screen.getByTestId('quality-record-button')
      await user.click(recordButton)
      
      expect(mockMediaDevices.getUserMedia).toHaveBeenCalledWith({
        audio: {
          sampleRate: 44100,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      })
    })
  })

  describe('Performance', () => {
    it('cleans up resources when unmounted', () => {
      const mockStream = {
        getTracks: vi.fn().mockReturnValue([
          { stop: vi.fn() }
        ])
      }
      
      mockMediaDevices.getUserMedia.mockResolvedValueOnce(mockStream as any)
      
      const TestComponent = () => {
        const [stream, setStream] = React.useState<MediaStream | null>(null)
        
        React.useEffect(() => {
          return () => {
            if (stream) {
              stream.getTracks().forEach(track => track.stop())
            }
          }
        }, [stream])
        
        const startRecording = async () => {
          const newStream = await navigator.mediaDevices.getUserMedia({ audio: true })
          setStream(newStream)
        }
        
        return (
          <button onClick={startRecording} data-testid="cleanup-test-button">
            Start Recording
          </button>
        )
      }
      
      const { unmount } = render(<TestComponent />)
      
      // Component should unmount without errors
      expect(() => unmount()).not.toThrow()
    })

    it('handles multiple rapid clicks gracefully', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      
      // Click multiple times rapidly
      await user.click(recordButton)
      await user.click(recordButton)
      await user.click(recordButton)
      
      // Should handle gracefully without crashes
      expect(recordButton).toBeInTheDocument()
    })
  })

  describe('Accessibility', () => {
    it('has proper ARIA labels', () => {
      const TestComponent = () => (
        <button 
          aria-label="Start audio recording"
          aria-describedby="recording-instructions"
          data-testid="accessible-record-button"
        >
          Start Recording
        </button>
      )
      
      render(<TestComponent />)
      
      const recordButton = screen.getByTestId('accessible-record-button')
      expect(recordButton).toHaveAttribute('aria-label', 'Start audio recording')
      expect(recordButton).toHaveAttribute('aria-describedby', 'recording-instructions')
    })

    it('announces recording state changes', async () => {
      const user = userEvent.setup()
      
      const TestComponent = () => {
        const [isRecording, setIsRecording] = React.useState(false)
        const [announcement, setAnnouncement] = React.useState('')
        
        const toggleRecording = () => {
          setIsRecording(!isRecording)
          setAnnouncement(isRecording ? 'Recording stopped' : 'Recording started')
        }
        
        return (
          <div>
            <button onClick={toggleRecording} data-testid="accessible-toggle-button">
              {isRecording ? 'Stop Recording' : 'Start Recording'}
            </button>
            <div role="status" aria-live="polite" data-testid="status-announcement">
              {announcement}
            </div>
          </div>
        )
      }
      
      render(<TestComponent />)
      
      const recordButton = screen.getByTestId('accessible-toggle-button')
      await user.click(recordButton)
      
      const statusAnnouncement = screen.getByTestId('status-announcement')
      expect(statusAnnouncement).toHaveTextContent('Recording started')
      expect(statusAnnouncement).toHaveAttribute('role', 'status')
      expect(statusAnnouncement).toHaveAttribute('aria-live', 'polite')
    })

    it('supports keyboard navigation', async () => {
      const user = userEvent.setup()
      render(<MockAudioRecorder onRecordingComplete={mockOnRecordingComplete} />)
      
      const recordButton = screen.getByTestId('record-button')
      
      // Tab to focus the button
      await user.tab()
      expect(recordButton).toHaveFocus()
      
      // Press Enter to activate
      await user.keyboard('{Enter}')
      expect(recordButton).toHaveTextContent('Stop Recording')
      
      // Press Space to stop
      await user.keyboard(' ')
      expect(recordButton).toHaveTextContent('Start Recording')
    })
  })
})