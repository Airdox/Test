import React, { ReactElement } from 'react'
import { render, RenderOptions } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { vi } from 'vitest'

// Custom render function that includes providers
const AllTheProviders = ({ children }: { children: React.ReactNode }) => {
  return (
    <div data-testid="test-wrapper">
      {children}
    </div>
  )
}

const customRender = (
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
) => {
  const user = userEvent.setup()
  
  return {
    user,
    ...render(ui, { wrapper: AllTheProviders, ...options })
  }
}

// Re-export everything
export * from '@testing-library/react'
export { customRender as render }

// Test utilities for audio functionality
export const createMockAudioContext = () => {
  const mockAnalyser = {
    fftSize: 2048,
    frequencyBinCount: 1024,
    minDecibels: -100,
    maxDecibels: -30,
    smoothingTimeConstant: 0.8,
    getFloatFrequencyData: vi.fn(),
    getByteFrequencyData: vi.fn(),
    getFloatTimeDomainData: vi.fn(),
    getByteTimeDomainData: vi.fn(),
    connect: vi.fn(),
    disconnect: vi.fn()
  }

  const mockGain = {
    gain: {
      value: 1,
      setValueAtTime: vi.fn(),
      linearRampToValueAtTime: vi.fn(),
      exponentialRampToValueAtTime: vi.fn()
    },
    connect: vi.fn(),
    disconnect: vi.fn()
  }

  const mockOscillator = {
    frequency: {
      value: 440,
      setValueAtTime: vi.fn(),
      linearRampToValueAtTime: vi.fn(),
      exponentialRampToValueAtTime: vi.fn()
    },
    type: 'sine',
    start: vi.fn(),
    stop: vi.fn(),
    connect: vi.fn(),
    disconnect: vi.fn()
  }

  const mockSource = {
    connect: vi.fn(),
    disconnect: vi.fn(),
    mediaStream: {} as MediaStream
  }

  return {
    state: 'running' as AudioContextState,
    sampleRate: 44100,
    currentTime: 0,
    destination: {},
    listener: {},
    createAnalyser: vi.fn().mockReturnValue(mockAnalyser),
    createGain: vi.fn().mockReturnValue(mockGain),
    createOscillator: vi.fn().mockReturnValue(mockOscillator),
    createMediaStreamSource: vi.fn().mockReturnValue(mockSource),
    decodeAudioData: vi.fn().mockResolvedValue({
      sampleRate: 44100,
      length: 44100,
      duration: 1,
      numberOfChannels: 2,
      getChannelData: vi.fn().mockReturnValue(new Float32Array(44100))
    }),
    suspend: vi.fn().mockResolvedValue(undefined),
    resume: vi.fn().mockResolvedValue(undefined),
    close: vi.fn().mockResolvedValue(undefined)
  }
}

export const createMockMediaRecorder = () => {
  class MockMediaRecorder {
    state: 'inactive' | 'recording' | 'paused' = 'inactive'
    stream: MediaStream
    ondataavailable: ((event: BlobEvent) => void) | null = null
    onstop: (() => void) | null = null
    onerror: ((event: Event) => void) | null = null
    onstart: (() => void) | null = null
    onpause: (() => void) | null = null
    onresume: (() => void) | null = null
    mimeType = 'audio/webm'
    
    constructor(stream: MediaStream) {
      this.stream = stream
    }
    
    start = vi.fn().mockImplementation(() => {
      this.state = 'recording'
      if (this.onstart) this.onstart()
      
      setTimeout(() => {
        if (this.ondataavailable) {
          const mockBlob = new Blob(['mock-audio-data'], { type: 'audio/webm' })
          const event = new Event('dataavailable') as BlobEvent
          Object.defineProperty(event, 'data', { value: mockBlob })
          this.ondataavailable(event)
        }
      }, 100)
    })
    
    stop = vi.fn().mockImplementation(() => {
      this.state = 'inactive'
      if (this.onstop) this.onstop()
    })
    
    pause = vi.fn().mockImplementation(() => {
      this.state = 'paused'
      if (this.onpause) this.onpause()
    })
    
    resume = vi.fn().mockImplementation(() => {
      this.state = 'recording'
      if (this.onresume) this.onresume()
    })
    
    requestData = vi.fn().mockImplementation(() => {
      if (this.ondataavailable) {
        const mockBlob = new Blob(['mock-audio-data'], { type: 'audio/webm' })
        const event = new Event('dataavailable') as BlobEvent
        Object.defineProperty(event, 'data', { value: mockBlob })
        this.ondataavailable(event)
      }
    })
    
    static isTypeSupported = vi.fn().mockImplementation((type: string) => {
      return ['audio/webm', 'audio/mp4', 'audio/wav'].includes(type)
    })
  }
  
  return MockMediaRecorder
}

export const createMockFile = (
  name: string = 'test.wav',
  content: string = 'mock-audio-data',
  type: string = 'audio/wav'
): File => {
  const file = new File([content], name, { type })
  return file
}

export const createMockFileList = (files: File[]): FileList => {
  const fileList = {
    length: files.length,
    item: (index: number) => files[index] || null,
    [Symbol.iterator]: function* () {
      for (let i = 0; i < files.length; i++) {
        yield files[i]
      }
    }
  }
  
  // Add numeric indices
  files.forEach((file, index) => {
    Object.defineProperty(fileList, index, {
      value: file,
      enumerable: true
    })
  })
  
  return fileList as FileList
}

export const createMockDataTransfer = (files: File[]): DataTransfer => {
  return {
    files: createMockFileList(files),
    items: {
      length: files.length,
      add: vi.fn(),
      clear: vi.fn(),
      remove: vi.fn()
    } as any,
    types: files.map(f => f.type),
    dropEffect: 'copy',
    effectAllowed: 'all',
    getData: vi.fn(),
    setData: vi.fn(),
    clearData: vi.fn(),
    setDragImage: vi.fn()
  } as DataTransfer
}

export const mockMediaDevices = {
  getUserMedia: vi.fn().mockResolvedValue({
    getTracks: vi.fn().mockReturnValue([{
      stop: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      kind: 'audio',
      label: 'Mock Microphone',
      enabled: true,
      muted: false,
      readyState: 'live'
    }]),
    getAudioTracks: vi.fn().mockReturnValue([{
      stop: vi.fn(),
      kind: 'audio',
      label: 'Mock Microphone'
    }]),
    getVideoTracks: vi.fn().mockReturnValue([]),
    active: true,
    id: 'mock-stream'
  }),
  enumerateDevices: vi.fn().mockResolvedValue([
    {
      deviceId: 'mock-audio-input',
      kind: 'audioinput',
      label: 'Mock Microphone',
      groupId: 'mock-group'
    }
  ])
}

export const waitForAudioLoad = async (audioElement: HTMLAudioElement) => {
  return new Promise<void>((resolve) => {
    if (audioElement.readyState >= 2) {
      resolve()
    } else {
      audioElement.addEventListener('canplay', () => resolve(), { once: true })
    }
  })
}

export const triggerAudioEvent = (
  audioElement: HTMLAudioElement,
  eventType: string,
  properties: Record<string, any> = {}
) => {
  const event = new Event(eventType)
  Object.assign(event, properties)
  audioElement.dispatchEvent(event)
}

export const mockVoiceCloneApi = {
  analyzeVoice: vi.fn().mockResolvedValue({
    voiceId: 'voice-123',
    characteristics: {
      pitch: 220,
      tone: 'warm',
      accent: 'neutral',
      speed: 1.0
    },
    quality: 85
  }),
  cloneVoice: vi.fn().mockResolvedValue({
    modelId: 'model-456',
    status: 'processing',
    estimatedTime: 300
  }),
  synthesizeSpeech: vi.fn().mockResolvedValue({
    audioUrl: 'mock-generated-audio-url',
    duration: 5.5
  }),
  getTrainingStatus: vi.fn().mockResolvedValue({
    modelId: 'model-456',
    status: 'completed',
    progress: 100,
    accuracy: 92.5
  })
}

export const mockPerformanceAnalytics = {
  startTiming: vi.fn(),
  endTiming: vi.fn().mockReturnValue(150),
  recordMetric: vi.fn(),
  getMetrics: vi.fn().mockReturnValue({
    averageProcessingTime: 145,
    memoryUsage: 25.6,
    errorRate: 0.02
  })
}

// Accessibility testing helpers
export const axeMatchers = {
  toHaveNoViolations: (received: any) => {
    // Mock implementation - would use real axe-core in actual tests
    return {
      pass: true,
      message: () => 'No accessibility violations found'
    }
  }
}

// Performance testing helpers
export const performanceHelpers = {
  measureRenderTime: async (renderFn: () => void) => {
    const start = performance.now()
    renderFn()
    const end = performance.now()
    return end - start
  },
  
  measureMemoryUsage: () => {
    // Mock implementation
    return {
      usedJSHeapSize: 1024 * 1024 * 25, // 25MB
      totalJSHeapSize: 1024 * 1024 * 100, // 100MB
      jsHeapSizeLimit: 1024 * 1024 * 1024 // 1GB
    }
  }
}

// Visual regression testing helpers
export const visualTestingHelpers = {
  takeScreenshot: vi.fn().mockResolvedValue('screenshot-data'),
  compareScreenshots: vi.fn().mockResolvedValue({
    passed: true,
    difference: 0.001
  })
}

export default customRender