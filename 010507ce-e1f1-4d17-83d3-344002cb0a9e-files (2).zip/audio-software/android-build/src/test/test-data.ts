// Test data factories and fixtures

export const createMockAudioRecording = (overrides = {}) => ({
  id: 'rec-123',
  name: 'Test Recording',
  blob: new Blob(['mock-audio-data'], { type: 'audio/wav' }),
  duration: 30,
  createdAt: new Date('2024-01-01T12:00:00Z'),
  url: 'mock-object-url',
  size: 1024,
  format: 'wav',
  ...overrides
})

export const createMockVoiceModel = (overrides = {}) => ({
  id: 'model-456',
  name: 'Test Voice Model',
  isTraining: false,
  trainingProgress: 100,
  accuracy: 95.5,
  createdAt: new Date('2024-01-01T12:00:00Z'),
  updatedAt: new Date('2024-01-01T15:30:00Z'),
  trainingData: ['rec-123', 'rec-456'],
  voiceCharacteristics: {
    pitch: 220,
    tone: 'warm',
    accent: 'neutral',
    speed: 1.0,
    gender: 'neutral'
  },
  metadata: {
    version: '1.0',
    language: 'en-US',
    quality: 'high'
  },
  ...overrides
})

export const createMockTrainingSession = (overrides = {}) => ({
  id: 'session-789',
  modelId: 'model-456',
  status: 'running' as const,
  progress: 45,
  startTime: new Date('2024-01-01T14:00:00Z'),
  estimatedEndTime: new Date('2024-01-01T16:00:00Z'),
  currentEpoch: 45,
  totalEpochs: 100,
  loss: 0.125,
  accuracy: 0.875,
  metrics: {
    learningRate: 0.001,
    batchSize: 32,
    validationLoss: 0.135,
    validationAccuracy: 0.865
  },
  logs: [
    'Starting training session...',
    'Epoch 1/100 - Loss: 0.850, Accuracy: 0.450',
    'Epoch 10/100 - Loss: 0.420, Accuracy: 0.720',
    'Epoch 45/100 - Loss: 0.125, Accuracy: 0.875'
  ],
  ...overrides
})

export const createMockSynthesisResult = (overrides = {}) => ({
  id: 'synthesis-321',
  text: 'Hello, this is a test of voice synthesis.',
  modelId: 'model-456',
  audioUrl: 'mock-synthesized-audio-url',
  duration: 5.5,
  format: 'wav',
  createdAt: new Date('2024-01-01T16:00:00Z'),
  settings: {
    speed: 1.0,
    pitch: 1.0,
    volume: 0.8,
    emotion: 'neutral',
    emphasis: []
  },
  quality: 92,
  processingTime: 2.3,
  ...overrides
})

export const createMockAudioAnalysis = (overrides = {}) => ({
  id: 'analysis-654',
  recordingId: 'rec-123',
  voiceCharacteristics: {
    fundamentalFrequency: 185.5,
    formants: [800, 1200, 2400],
    spectralCentroid: 1500.5,
    zeroCrossingRate: 0.15,
    mfcc: [12.5, -8.2, 5.1, -2.3, 1.8, -0.9, 0.7, -0.4, 0.2, -0.1, 0.05, -0.02, 0.01],
    energy: 0.75,
    pitch: {
      mean: 185.5,
      std: 15.2,
      min: 160.0,
      max: 220.0
    },
    tempo: 120,
    rhythm: [0.5, 0.3, 0.2, 0.4, 0.6, 0.3, 0.1, 0.4]
  },
  audioQuality: {
    snr: 25.5,
    thd: 0.02,
    backgroundNoise: 0.05,
    clipping: false,
    overallScore: 8.5
  },
  speakerClassification: {
    gender: 'female',
    ageRange: '25-35',
    accent: 'american-general',
    confidence: 0.92
  },
  processingTime: 1.8,
  createdAt: new Date('2024-01-01T12:05:00Z'),
  ...overrides
})

export const createMockApiResponse = <T>(data: T, overrides = {}) => ({
  success: true,
  data,
  message: 'Request successful',
  timestamp: new Date().toISOString(),
  requestId: 'req-' + Math.random().toString(36).substr(2, 9),
  ...overrides
})

export const createMockApiError = (overrides = {}) => ({
  success: false,
  error: {
    code: 'VALIDATION_ERROR',
    message: 'Invalid request parameters',
    details: {}
  },
  timestamp: new Date().toISOString(),
  requestId: 'req-' + Math.random().toString(36).substr(2, 9),
  ...overrides
})

export const mockApiEndpoints = {
  recordings: {
    list: '/api/recordings',
    create: '/api/recordings',
    get: (id: string) => `/api/recordings/${id}`,
    update: (id: string) => `/api/recordings/${id}`,
    delete: (id: string) => `/api/recordings/${id}`,
    analyze: (id: string) => `/api/recordings/${id}/analyze`
  },
  voiceModels: {
    list: '/api/voice-models',
    create: '/api/voice-models',
    get: (id: string) => `/api/voice-models/${id}`,
    update: (id: string) => `/api/voice-models/${id}`,
    delete: (id: string) => `/api/voice-models/${id}`,
    train: (id: string) => `/api/voice-models/${id}/train`,
    clone: '/api/voice-models/clone'
  },
  synthesis: {
    synthesize: '/api/synthesis/synthesize',
    list: '/api/synthesis',
    get: (id: string) => `/api/synthesis/${id}`
  },
  training: {
    sessions: '/api/training/sessions',
    get: (id: string) => `/api/training/sessions/${id}`,
    logs: (id: string) => `/api/training/sessions/${id}/logs`,
    cancel: (id: string) => `/api/training/sessions/${id}/cancel`
  }
}

// Performance test data
export const performanceTestData = {
  largeAudioFile: {
    size: 50 * 1024 * 1024, // 50MB
    duration: 300, // 5 minutes
    format: 'wav',
    sampleRate: 44100,
    channels: 2
  },
  mediumAudioFile: {
    size: 10 * 1024 * 1024, // 10MB
    duration: 60, // 1 minute
    format: 'mp3',
    sampleRate: 44100,
    channels: 2
  },
  smallAudioFile: {
    size: 1024 * 1024, // 1MB
    duration: 10, // 10 seconds
    format: 'wav',
    sampleRate: 22050,
    channels: 1
  }
}

// UI test data
export const uiTestData = {
  longText: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  shortText: 'Hello world',
  specialCharacters: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  unicodeText: '🎵 Audio Studio 🎤 Voice Clone 🔊',
  multilineText: 'Line 1\nLine 2\nLine 3',
  emptyText: ''
}

// Edge case test data
export const edgeCaseTestData = {
  extremelyLongFileName: 'a'.repeat(255) + '.wav',
  invalidFileName: 'file<>:|"?*.wav',
  zeroSizeFile: new Blob([], { type: 'audio/wav' }),
  hugeFile: new Blob(['x'.repeat(1000000)], { type: 'audio/wav' }),
  unsupportedFormat: new Blob(['data'], { type: 'audio/xyz' }),
  corruptedAudio: new Blob(['invalid-audio-data'], { type: 'audio/wav' })
}

// Accessibility test data
export const a11yTestData = {
  screenReaderLabels: [
    'Record audio',
    'Upload file',
    'Play recording',
    'Delete recording',
    'Download recording',
    'Training progress',
    'Voice model status'
  ],
  keyboardNavigation: [
    'Tab',
    'Shift+Tab',
    'Enter',
    'Space',
    'Escape',
    'ArrowUp',
    'ArrowDown',
    'ArrowLeft',
    'ArrowRight'
  ],
  colorContrast: {
    minimumRatio: 4.5,
    enhancedRatio: 7
  }
}