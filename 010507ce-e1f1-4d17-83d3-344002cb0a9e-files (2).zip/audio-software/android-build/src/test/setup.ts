import '@testing-library/jest-dom'
import { cleanup } from '@testing-library/react'
import { afterEach, beforeAll, afterAll, vi } from 'vitest'

// Cleanup after each test case
afterEach(() => {
  cleanup()
})

// Mock Web APIs
const mockMediaDevicesConstructor = () => ({
  getUserMedia: vi.fn().mockResolvedValue({
    getTracks: vi.fn().mockReturnValue([
      {
        stop: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        kind: 'audio',
        label: 'Mock Audio Track',
        enabled: true,
        muted: false,
        readyState: 'live'
      }
    ]),
    getAudioTracks: vi.fn().mockReturnValue([
      {
        stop: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        kind: 'audio',
        label: 'Mock Audio Track',
        enabled: true,
        muted: false,
        readyState: 'live'
      }
    ]),
    getVideoTracks: vi.fn().mockReturnValue([]),
    active: true,
    id: 'mock-stream'
  }),
  enumerateDevices: vi.fn().mockResolvedValue([
    {
      deviceId: 'mock-audio-input',
      kind: 'audioinput',
      label: 'Mock Microphone',
      groupId: 'mock-group'
    }
  ]),
  getDisplayMedia: vi.fn(),
  getSupportedConstraints: vi.fn().mockReturnValue({
    audio: true,
    video: true
  })
})

// Mock MediaRecorder
class MockMediaRecorder {
  state: 'inactive' | 'recording' | 'paused' = 'inactive'
  stream: MediaStream
  ondataavailable: ((event: BlobEvent) => void) | null = null
  onstop: (() => void) | null = null
  onerror: ((event: Event) => void) | null = null
  onstart: (() => void) | null = null
  onpause: (() => void) | null = null
  onresume: (() => void) | null = null
  mimeType = 'audio/webm'
  
  constructor(stream: MediaStream, options?: MediaRecorderOptions) {
    this.stream = stream
  }
  
  start(timeslice?: number) {
    this.state = 'recording'
    if (this.onstart) this.onstart()
    
    // Simulate data available after a short delay
    setTimeout(() => {
      if (this.ondataavailable) {
        const mockBlob = new Blob(['mock-audio-data'], { type: 'audio/webm' })
        const event = new Event('dataavailable') as BlobEvent
        Object.defineProperty(event, 'data', { value: mockBlob })
        this.ondataavailable(event)
      }
    }, 100)
  }
  
  stop() {
    this.state = 'inactive'
    if (this.onstop) this.onstop()
  }
  
  pause() {
    this.state = 'paused'
    if (this.onpause) this.onpause()
  }
  
  resume() {
    this.state = 'recording'
    if (this.onresume) this.onresume()
  }
  
  requestData() {
    if (this.ondataavailable) {
      const mockBlob = new Blob(['mock-audio-data'], { type: 'audio/webm' })
      const event = new Event('dataavailable') as BlobEvent
      Object.defineProperty(event, 'data', { value: mockBlob })
      this.ondataavailable(event)
    }
  }
  
  static isTypeSupported(type: string): boolean {
    return ['audio/webm', 'audio/mp4', 'audio/wav'].includes(type)
  }
}

// Mock Audio Context
class MockAudioContext {
  state: 'suspended' | 'running' | 'closed' = 'running'
  sampleRate = 44100
  currentTime = 0
  destination = {}
  listener = {}
  
  createAnalyser() {
    return {
      fftSize: 2048,
      frequencyBinCount: 1024,
      minDecibels: -100,
      maxDecibels: -30,
      smoothingTimeConstant: 0.8,
      getFloatFrequencyData: vi.fn(),
      getByteFrequencyData: vi.fn(),
      getFloatTimeDomainData: vi.fn(),
      getByteTimeDomainData: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn()
    }
  }
  
  createMediaStreamSource(stream: MediaStream) {
    return {
      connect: vi.fn(),
      disconnect: vi.fn(),
      mediaStream: stream
    }
  }
  
  createGain() {
    return {
      gain: {
        value: 1,
        setValueAtTime: vi.fn(),
        linearRampToValueAtTime: vi.fn(),
        exponentialRampToValueAtTime: vi.fn()
      },
      connect: vi.fn(),
      disconnect: vi.fn()
    }
  }
  
  createOscillator() {
    return {
      frequency: {
        value: 440,
        setValueAtTime: vi.fn(),
        linearRampToValueAtTime: vi.fn(),
        exponentialRampToValueAtTime: vi.fn()
      },
      type: 'sine',
      start: vi.fn(),
      stop: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn()
    }
  }
  
  decodeAudioData(audioData: ArrayBuffer) {
    return Promise.resolve({
      sampleRate: 44100,
      length: 44100,
      duration: 1,
      numberOfChannels: 2,
      getChannelData: vi.fn().mockReturnValue(new Float32Array(44100))
    })
  }
  
  suspend() {
    this.state = 'suspended'
    return Promise.resolve()
  }
  
  resume() {
    this.state = 'running'
    return Promise.resolve()
  }
  
  close() {
    this.state = 'closed'
    return Promise.resolve()
  }
}

// Mock Audio Element
class MockAudio {
  src = ''
  currentTime = 0
  duration = 0
  paused = true
  ended = false
  volume = 1
  muted = false
  playbackRate = 1
  
  addEventListener = vi.fn()
  removeEventListener = vi.fn()
  
  play() {
    this.paused = false
    return Promise.resolve()
  }
  
  pause() {
    this.paused = true
  }
  
  load() {
    // Mock load
  }
  
  canPlayType(type: string): string {
    const supportedTypes = ['audio/mpeg', 'audio/wav', 'audio/ogg']
    return supportedTypes.includes(type) ? 'probably' : ''
  }
}

// Setup global mocks
beforeAll(() => {
  // Mock navigator.mediaDevices
  Object.defineProperty(navigator, 'mediaDevices', {
    writable: true,
    value: mockMediaDevicesConstructor()
  })
  
  // Mock MediaRecorder
  global.MediaRecorder = MockMediaRecorder as any
  
  // Mock AudioContext
  global.AudioContext = MockAudioContext as any
  global.webkitAudioContext = MockAudioContext as any
  
  // Mock Audio
  global.Audio = MockAudio as any
  
  // Mock URL.createObjectURL and URL.revokeObjectURL
  global.URL.createObjectURL = vi.fn().mockReturnValue('mock-object-url')
  global.URL.revokeObjectURL = vi.fn()
  
  // Mock Blob
  global.Blob = class MockBlob {
    size: number
    type: string
    
    constructor(parts: any[], options?: BlobPropertyBag) {
      this.size = parts.reduce((acc, part) => acc + (part?.length || 0), 0)
      this.type = options?.type || ''
    }
    
    arrayBuffer(): Promise<ArrayBuffer> {
      return Promise.resolve(new ArrayBuffer(this.size))
    }
    
    text(): Promise<string> {
      return Promise.resolve('mock-blob-text')
    }
    
    stream(): ReadableStream {
      return new ReadableStream()
    }
    
    slice(start?: number, end?: number, contentType?: string): Blob {
      return new MockBlob([], { type: contentType })
    }
  } as any
  
  // Mock FileReader
  global.FileReader = class MockFileReader {
    result: string | ArrayBuffer | null = null
    error: DOMException | null = null
    readyState: number = 0
    
    onload: ((event: ProgressEvent<FileReader>) => void) | null = null
    onerror: ((event: ProgressEvent<FileReader>) => void) | null = null
    onabort: ((event: ProgressEvent<FileReader>) => void) | null = null
    onloadstart: ((event: ProgressEvent<FileReader>) => void) | null = null
    onloadend: ((event: ProgressEvent<FileReader>) => void) | null = null
    onprogress: ((event: ProgressEvent<FileReader>) => void) | null = null
    
    addEventListener = vi.fn()
    removeEventListener = vi.fn()
    dispatchEvent = vi.fn()
    
    readAsArrayBuffer(blob: Blob) {
      this.readyState = 1
      setTimeout(() => {
        this.result = new ArrayBuffer(blob.size)
        this.readyState = 2
        if (this.onload) {
          this.onload({} as ProgressEvent<FileReader>)
        }
      }, 10)
    }
    
    readAsText(blob: Blob) {
      this.readyState = 1
      setTimeout(() => {
        this.result = 'mock-file-content'
        this.readyState = 2
        if (this.onload) {
          this.onload({} as ProgressEvent<FileReader>)
        }
      }, 10)
    }
    
    readAsDataURL(blob: Blob) {
      this.readyState = 1
      setTimeout(() => {
        this.result = 'data:audio/wav;base64,mock-data-url'
        this.readyState = 2
        if (this.onload) {
          this.onload({} as ProgressEvent<FileReader>)
        }
      }, 10)
    }
    
    abort() {
      this.readyState = 2
      if (this.onabort) {
        this.onabort({} as ProgressEvent<FileReader>)
      }
    }
    
    static readonly EMPTY = 0
    static readonly LOADING = 1
    static readonly DONE = 2
  } as any
  
  // Mock localStorage
  const localStorageMock = {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
    key: vi.fn(),
    length: 0
  }
  
  Object.defineProperty(window, 'localStorage', {
    value: localStorageMock
  })
  
  // Mock performance.now
  Object.defineProperty(window, 'performance', {
    value: {
      now: vi.fn().mockReturnValue(Date.now())
    }
  })
  
  // Mock ResizeObserver
  global.ResizeObserver = class MockResizeObserver {
    observe = vi.fn()
    unobserve = vi.fn()
    disconnect = vi.fn()
    
    constructor(callback: ResizeObserverCallback) {
      // Mock constructor
    }
  } as any
  
  // Mock IntersectionObserver
  global.IntersectionObserver = class MockIntersectionObserver {
    observe = vi.fn()
    unobserve = vi.fn()
    disconnect = vi.fn()
    
    constructor(callback: IntersectionObserverCallback, options?: IntersectionObserverInit) {
      // Mock constructor
    }
  } as any
})

afterAll(() => {
  vi.restoreAllMocks()
})

// Global test utilities
export const mockAudioFile = (name = 'test.wav', size = 1024, type = 'audio/wav') => {
  const file = new File(['mock-audio-data'], name, { type })
  Object.defineProperty(file, 'size', { value: size })
  return file
}

export const mockAudioRecording = (overrides = {}) => ({
  id: 'test-recording-1',
  name: 'Test Recording',
  blob: new Blob(['mock-audio-data'], { type: 'audio/wav' }),
  duration: 30,
  createdAt: new Date('2024-01-01T12:00:00Z'),
  url: 'mock-object-url',
  ...overrides
})

export const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

export const mockVoiceModel = (overrides = {}) => ({
  id: 'test-model-1',
  name: 'Test Voice Model',
  isTraining: false,
  trainingProgress: 100,
  accuracy: 95.5,
  createdAt: new Date('2024-01-01T12:00:00Z'),
  trainingData: ['recording-1', 'recording-2'],
  ...overrides
})