import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mic, 
  Square, 
  Play, 
  Pause, 
  Upload, 
  Download, 
  Volume2, 
  AudioWaveform,
  Clock,
  FileAudio,
  Trash2
} from "lucide-react";

interface AudioRecording {
  id: string;
  name: string;
  blob: Blob;
  duration: number;
  createdAt: Date;
  url: string;
}

export default function AudioSoftware() {
  // Recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [recordings, setRecordings] = useState<AudioRecording[]>([]);
  
  // Playback state
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>(null);
  const [playbackTime, setPlaybackTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  // Upload state
  const [isDragOver, setIsDragOver] = useState(false);
  
  // Refs
  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);
  const playbackInterval = useRef<NodeJS.Timeout | null>(null);

  // Start recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        chunks.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        const newRecording: AudioRecording = {
          id: Date.now().toString(),
          name: `Aufnahme ${new Date().toLocaleTimeString('de-DE')}`,
          blob,
          duration: recordingTime,
          createdAt: new Date(),
          url
        };
        setRecordings(prev => [newRecording, ...prev]);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
      
      recordingInterval.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Fehler beim Zugriff auf das Mikrofon:', err);
      alert('Mikrofon-Zugriff nicht möglich. Bitte Berechtigung erteilen.');
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      setMediaRecorder(null);
      if (recordingInterval.current) {
        clearInterval(recordingInterval.current);
      }
    }
  };

  // Play audio
  const playAudio = (recording: AudioRecording) => {
    if (currentlyPlaying === recording.id) {
      if (audioRef.current?.paused) {
        audioRef.current.play();
      } else {
        audioRef.current?.pause();
      }
      return;
    }

    if (audioRef.current) {
      audioRef.current.src = recording.url;
      audioRef.current.play();
      setCurrentlyPlaying(recording.id);
      
      playbackInterval.current = setInterval(() => {
        if (audioRef.current) {
          setPlaybackTime(audioRef.current.currentTime);
          setDuration(audioRef.current.duration || 0);
        }
      }, 100);
    }
  };

  // Handle audio end
  const handleAudioEnd = () => {
    setCurrentlyPlaying(null);
    setPlaybackTime(0);
    if (playbackInterval.current) {
      clearInterval(playbackInterval.current);
    }
  };

  // Handle file upload
  const handleFileUpload = (files: FileList) => {
    Array.from(files).forEach(file => {
      if (file.type.startsWith('audio/')) {
        const url = URL.createObjectURL(file);
        const newRecording: AudioRecording = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          name: file.name,
          blob: file,
          duration: 0,
          createdAt: new Date(),
          url
        };
        setRecordings(prev => [newRecording, ...prev]);
      }
    });
  };

  // Delete recording
  const deleteRecording = (id: string) => {
    setRecordings(prev => prev.filter(r => r.id !== id));
    if (currentlyPlaying === id) {
      setCurrentlyPlaying(null);
      audioRef.current?.pause();
    }
  };

  // Download recording
  const downloadRecording = (recording: AudioRecording) => {
    const a = document.createElement('a');
    a.href = recording.url;
    a.download = recording.name + '.wav';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Format time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files) {
      handleFileUpload(e.dataTransfer.files);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recordingInterval.current) clearInterval(recordingInterval.current);
      if (playbackInterval.current) clearInterval(playbackInterval.current);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-2xl bg-primary/10 backdrop-blur-sm">
              <AudioWaveform className="h-8 w-8 text-primary" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              Audio Studio
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professionelle Audio-Software für Aufnahme, Upload und Bearbeitung von Audiodateien
          </p>
        </div>

        <Tabs defaultValue="record" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3 p-1 bg-muted/50 backdrop-blur-sm">
            <TabsTrigger value="record" className="flex items-center gap-2">
              <Mic className="h-4 w-4" />
              Aufnehmen
            </TabsTrigger>
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Hochladen
            </TabsTrigger>
            <TabsTrigger value="library" className="flex items-center gap-2">
              <FileAudio className="h-4 w-4" />
              Bibliothek
            </TabsTrigger>
          </TabsList>

          {/* Recording Tab */}
          <TabsContent value="record">
            <Card className="border-0 shadow-xl bg-card/50 backdrop-blur-sm">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  <Mic className="h-5 w-5" />
                  Audio Aufnahme
                </CardTitle>
                <CardDescription>
                  Klicken Sie auf Aufnahme starten, um Audio aufzunehmen
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center space-y-6">
                  {/* Recording Button */}
                  <div className="relative">
                    <Button
                      size="lg"
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`h-20 w-20 rounded-full text-white shadow-lg transition-all duration-300 ${
                        isRecording 
                          ? 'bg-red-500 hover:bg-red-600 shadow-red-500/25 animate-pulse' 
                          : 'bg-primary hover:bg-primary/90 shadow-primary/25 hover:scale-105'
                      }`}
                    >
                      {isRecording ? <Square className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
                    </Button>
                    {isRecording && (
                      <div className="absolute -inset-2 rounded-full border-2 border-red-500/50 animate-ping" />
                    )}
                  </div>

                  {/* Recording Status */}
                  {isRecording && (
                    <div className="text-center space-y-3">
                      <Badge variant="destructive" className="px-4 py-2">
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-2 bg-white rounded-full animate-pulse" />
                          AUFNAHME LÄUFT
                        </div>
                      </Badge>
                      <div className="flex items-center justify-center gap-2 text-2xl font-mono">
                        <Clock className="h-5 w-5" />
                        {formatTime(recordingTime)}
                      </div>
                    </div>
                  )}

                  {!isRecording && (
                    <p className="text-center text-muted-foreground">
                      {recordings.length === 0 
                        ? "Bereit für die erste Aufnahme" 
                        : `${recordings.length} Aufnahme${recordings.length > 1 ? 'n' : ''} gespeichert`
                      }
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Upload Tab */}
          <TabsContent value="upload">
            <Card className="border-0 shadow-xl bg-card/50 backdrop-blur-sm">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  <Upload className="h-5 w-5" />
                  Audio hochladen
                </CardTitle>
                <CardDescription>
                  Ziehen Sie Audiodateien hierher oder klicken Sie zum Auswählen
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
                    isDragOver 
                      ? 'border-primary bg-primary/5 scale-105' 
                      : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/20'
                  }`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  <div className="space-y-4">
                    <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                      <Upload className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <p className="text-lg font-medium">
                        Audiodateien hier ablegen
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Unterstützte Formate: MP3, WAV, OGG, M4A
                      </p>
                    </div>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      variant="outline"
                      className="bg-background/50 backdrop-blur-sm"
                    >
                      Dateien auswählen
                    </Button>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Library Tab */}
          <TabsContent value="library">
            <Card className="border-0 shadow-xl bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileAudio className="h-5 w-5" />
                    Audio Bibliothek
                  </div>
                  <Badge variant="secondary">
                    {recordings.length} Datei{recordings.length !== 1 ? 'en' : ''}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Verwalten Sie Ihre Audioaufnahmen und hochgeladenen Dateien
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recordings.length === 0 ? (
                    <div className="text-center py-12">
                      <FileAudio className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground">
                        Noch keine Audiodateien vorhanden
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Nehmen Sie Audio auf oder laden Sie Dateien hoch
                      </p>
                    </div>
                  ) : (
                    recordings.map((recording) => (
                      <div
                        key={recording.id}
                        className="flex items-center justify-between p-4 rounded-lg border bg-background/50 backdrop-blur-sm hover:bg-muted/20 transition-colors"
                      >
                        <div className="flex items-center space-x-4 flex-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => playAudio(recording)}
                            className="p-2 h-10 w-10 rounded-full bg-primary/10 hover:bg-primary/20"
                          >
                            {currentlyPlaying === recording.id && !audioRef.current?.paused ? (
                              <Pause className="h-4 w-4" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </Button>
                          
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{recording.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {recording.createdAt.toLocaleString('de-DE')}
                              {recording.duration > 0 && ` • ${formatTime(recording.duration)}`}
                            </p>
                            
                            {currentlyPlaying === recording.id && (
                              <div className="mt-2 space-y-1">
                                <Progress value={(playbackTime / duration) * 100} className="h-1" />
                                <div className="flex justify-between text-xs text-muted-foreground">
                                  <span>{formatTime(playbackTime)}</span>
                                  <span>{formatTime(duration)}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => downloadRecording(recording)}
                            className="h-8 w-8 p-0"
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteRecording(recording.id)}
                            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Hidden Audio Element */}
        <audio
          ref={audioRef}
          onEnded={handleAudioEnd}
          onPause={() => {
            if (playbackInterval.current) {
              clearInterval(playbackInterval.current);
            }
          }}
          onPlay={() => {
            playbackInterval.current = setInterval(() => {
              if (audioRef.current) {
                setPlaybackTime(audioRef.current.currentTime);
                setDuration(audioRef.current.duration || 0);
              }
            }, 100);
          }}
        />
      </div>
    </div>
  );
}