import { test, expect } from '@playwright/test'

test.describe('Smoke Tests - Critical User Journeys', () => {
  test.beforeEach(async ({ page, context }) => {
    // Grant microphone permissions
    await context.grantPermissions(['microphone'])
    
    // Navigate to the app
    await page.goto('/')
    
    // Wait for app to load
    await page.waitForSelector('h1:has-text("VOICE CLONE")', { timeout: 10000 })
  })

  test('critical path: app loads and displays main interface', async ({ page }) => {
    // Verify main branding
    await expect(page.locator('h1')).toContainText('VOICE CLONE')
    await expect(page.locator('h1')).toContainText('STUDIO')
    
    // Verify main description
    await expect(page.locator('text=Professionelle Audio-Software')).toBeVisible()
    
    // Verify all tabs are present
    const tabs = [
      'Aufnehmen',
      'Hochladen', 
      'Bibliothek',
      'Voice Cloning',
      'Training'
    ]
    
    for (const tabName of tabs) {
      await expect(page.locator(`[role="tab"]:has-text("${tabName}")`)).toBeVisible()
    }
  })

  test('critical path: audio recording workflow', async ({ page }) => {
    // Mock audio APIs for smoke test
    await page.addInitScript(() => {
      navigator.mediaDevices.getUserMedia = async () => {
        const stream = new MediaStream()
        const track = { stop: () => {} } as any
        stream.addTrack(track)
        return stream
      }
      
      window.MediaRecorder = class {
        constructor() {}
        start() { 
          this.state = 'recording'
          setTimeout(() => {
            if (this.ondataavailable) {
              const blob = new Blob(['audio-data'], { type: 'audio/wav' })
              this.ondataavailable({ data: blob } as any)
            }
            if (this.onstop) this.onstop()
          }, 500)
        }
        stop() { this.state = 'inactive' }
        state = 'inactive'
        ondataavailable = null
        onstop = null
        onstart = null
      } as any
    })
    
    // Start recording
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    await expect(recordButton.first()).toBeVisible()
    await recordButton.first().click()
    
    // Verify recording state
    await expect(page.locator('text=AUFNAHME LÄUFT')).toBeVisible({ timeout: 2000 })
    
    // Stop recording
    const stopButton = page.locator('button:has-text("stoppen")')
    await stopButton.first().click()
    
    // Verify recording completed
    await expect(page.locator('text=AUFNAHME LÄUFT')).not.toBeVisible()
    
    // Check library has recording
    const libraryTab = page.locator('[role="tab"]:has-text("Bibliothek")')
    await libraryTab.click()
    
    // Should show recording in library
    await expect(page.locator('text=Aufnahme')).toBeVisible({ timeout: 2000 })
  })

  test('critical path: file upload workflow', async ({ page }) => {
    // Switch to upload tab
    const uploadTab = page.locator('[role="tab"]:has-text("Hochladen")')
    await uploadTab.click()
    
    // Verify upload interface
    await expect(page.locator('text=Audio hochladen')).toBeVisible()
    await expect(page.locator('text=Ziehen Sie Audiodateien hierher')).toBeVisible()
    await expect(page.locator('button:has-text("Dateien auswählen")')).toBeVisible()
    
    // Verify supported formats are mentioned
    await expect(page.locator('text=MP3, WAV, OGG, M4A')).toBeVisible()
  })

  test('critical path: navigation between tabs works', async ({ page }) => {
    const tabs = [
      { name: 'Aufnehmen', content: 'Audio Aufnahme' },
      { name: 'Hochladen', content: 'Audio hochladen' },
      { name: 'Bibliothek', content: 'Audio Bibliothek' },
      { name: 'Voice Cloning', content: 'Stimme klonen' },
      { name: 'Training', content: 'Modell Training' }
    ]
    
    for (const tab of tabs) {
      const tabElement = page.locator(`[role="tab"]:has-text("${tab.name}")`)
      await tabElement.click()
      
      // Verify tab is active
      await expect(tabElement).toHaveAttribute('data-state', 'active')
      
      // Verify content is displayed
      await expect(page.locator(`text=${tab.content}`)).toBeVisible()
    }
  })

  test('critical path: responsive design on mobile', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 })
    
    // Verify main elements are still visible
    await expect(page.locator('h1:has-text("VOICE CLONE")')).toBeVisible()
    
    // Verify tabs are accessible on mobile
    const recordingTab = page.locator('[role="tab"]:has-text("Aufnehmen")')
    await expect(recordingTab).toBeVisible()
    
    // Test tab switching on mobile
    const uploadTab = page.locator('[role="tab"]:has-text("Hochladen")')
    await uploadTab.click()
    await expect(uploadTab).toHaveAttribute('data-state', 'active')
  })

  test('critical path: accessibility basics', async ({ page }) => {
    // Check for proper heading structure
    const h1 = page.locator('h1')
    await expect(h1).toBeVisible()
    
    // Check for proper tab structure
    const tabList = page.locator('[role="tablist"]')
    await expect(tabList).toBeVisible()
    
    // Check tabs have proper roles
    const tabs = page.locator('[role="tab"]')
    const tabCount = await tabs.count()
    expect(tabCount).toBeGreaterThan(0)
    
    // Test keyboard navigation
    await page.keyboard.press('Tab')
    const firstTab = tabs.first()
    await expect(firstTab).toBeFocused()
  })

  test('critical path: performance basics', async ({ page }) => {
    // Measure page load time
    const startTime = Date.now()
    
    await page.goto('/')
    await page.waitForSelector('h1:has-text("VOICE CLONE")')
    
    const loadTime = Date.now() - startTime
    
    // Should load within reasonable time (adjust as needed)
    expect(loadTime).toBeLessThan(5000) // 5 seconds
    
    // Check for large layout shifts
    const cls = await page.evaluate(() => {
      return new Promise((resolve) => {
        let clsScore = 0
        const observer = new PerformanceObserver((entryList) => {
          for (const entry of entryList.getEntries()) {
            if ((entry as any).hadRecentInput) continue
            clsScore += (entry as any).value
          }
          resolve(clsScore)
        })
        observer.observe({ entryTypes: ['layout-shift'] })
        
        // Resolve after a short timeout
        setTimeout(() => resolve(clsScore), 2000)
      })
    })
    
    // CLS should be low (good user experience)
    expect(cls).toBeLessThan(0.1)
  })

  test('critical path: error handling', async ({ page }) => {
    // Test with denied microphone permissions
    await page.context().clearPermissions()
    
    // Mock getUserMedia to throw error
    await page.addInitScript(() => {
      navigator.mediaDevices.getUserMedia = async () => {
        throw new DOMException('Permission denied', 'NotAllowedError')
      }
    })
    
    // Mock alert for testing
    let alertMessage = ''
    page.on('dialog', async (dialog) => {
      alertMessage = dialog.message()
      await dialog.accept()
    })
    
    // Try to record
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    await recordButton.first().click()
    
    // Should handle error gracefully
    await page.waitForTimeout(1000)
    expect(alertMessage).toContain('Mikrofon-Zugriff')
    
    // App should still be functional
    await expect(page.locator('h1:has-text("VOICE CLONE")')).toBeVisible()
  })
})