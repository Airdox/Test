import { test, expect, Page } from '@playwright/test'

test.describe('Audio Recording E2E Tests', () => {
  let page: Page

  test.beforeEach(async ({ page: p, context }) => {
    page = p
    
    // Grant microphone permissions
    await context.grantPermissions(['microphone'])
    
    // Navigate to the app
    await page.goto('/')
    
    // Wait for app to load
    await page.waitForSelector('h1:has-text("VOICE CLONE")', { timeout: 10000 })
  })

  test('should display the main interface correctly', async () => {
    // Check main heading
    await expect(page.locator('h1')).toContainText('VOICE CLONE')
    await expect(page.locator('h1')).toContainText('STUDIO')
    
    // Check description
    await expect(page.locator('text=Professionelle Audio-Software')).toBeVisible()
    
    // Check navigation tabs
    await expect(page.locator('[role="tab"]:has-text("Aufnehmen")')).toBeVisible()
    await expect(page.locator('[role="tab"]:has-text("Hochladen")')).toBeVisible()
    await expect(page.locator('[role="tab"]:has-text("Bibliothek")')).toBeVisible()
  })

  test('should start and stop audio recording', async () => {
    // Mock getUserMedia for testing
    await page.addInitScript(() => {
      navigator.mediaDevices.getUserMedia = async () => {
        const stream = new MediaStream()
        const track = {
          stop: () => {},
          addEventListener: () => {},
          removeEventListener: () => {},
          kind: 'audio',
          label: 'Mock Microphone',
          enabled: true,
          muted: false,
          readyState: 'live'
        } as any
        
        stream.addTrack(track)
        return stream
      }
      
      window.MediaRecorder = class {
        constructor() {}
        start() { 
          setTimeout(() => {
            if (this.onstart) this.onstart()
          }, 100)
        }
        stop() { 
          setTimeout(() => {
            if (this.onstop) this.onstop()
          }, 100)
        }
        state = 'inactive'
        ondataavailable = null
        onstop = null
        onstart = null
      } as any
    })
    
    // Ensure we're on the recording tab
    const recordingTab = page.locator('[role="tab"]:has-text("Aufnehmen")')
    if (!(await recordingTab.getAttribute('data-state')) === 'active') {
      await recordingTab.click()
    }
    
    // Find and click the record button
    const recordButton = page.locator('button:has-text("Aufnahme starten"), button[aria-label*="record"], button:has([data-testid="mic-icon"])')
    await expect(recordButton.first()).toBeVisible()
    await recordButton.first().click()
    
    // Check that recording started
    await expect(page.locator('text=AUFNAHME LÄUFT, text=Recording')).toBeVisible({ timeout: 5000 })
    
    // Wait a moment for recording to be active
    await page.waitForTimeout(1000)
    
    // Stop recording
    const stopButton = page.locator('button:has-text("stoppen"), button:has([data-testid="stop-icon"])')
    await stopButton.first().click()
    
    // Check that recording stopped
    await expect(page.locator('text=AUFNAHME LÄUFT')).not.toBeVisible()
  })

  test('should handle microphone permission denial', async ({ context }) => {
    // Deny microphone permissions
    await context.clearPermissions()
    
    // Mock getUserMedia to throw permission error
    await page.addInitScript(() => {
      navigator.mediaDevices.getUserMedia = async () => {
        throw new DOMException('Permission denied', 'NotAllowedError')
      }
    })
    
    // Mock alert to capture the error message
    let alertMessage = ''
    page.on('dialog', async (dialog) => {
      alertMessage = dialog.message()
      await dialog.accept()
    })
    
    // Try to start recording
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    await recordButton.first().click()
    
    // Check that error was shown
    await page.waitForTimeout(1000)
    expect(alertMessage).toContain('Mikrofon-Zugriff nicht möglich')
  })

  test('should display recording timer', async () => {
    // Mock media APIs
    await page.addInitScript(() => {
      let recordingTime = 0
      
      navigator.mediaDevices.getUserMedia = async () => {
        const stream = new MediaStream()
        const track = { stop: () => {} } as any
        stream.addTrack(track)
        return stream
      }
      
      window.MediaRecorder = class {
        constructor() {}
        start() {
          this.state = 'recording'
          if (this.onstart) this.onstart()
        }
        stop() {
          this.state = 'inactive'
          if (this.onstop) this.onstop()
        }
        state = 'inactive'
        ondataavailable = null
        onstop = null
        onstart = null
      } as any
    })
    
    // Start recording
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    await recordButton.first().click()
    
    // Check that timer appears
    await expect(page.locator('text=0:00, text=0:01').first()).toBeVisible({ timeout: 2000 })
  })

  test('should navigate between tabs', async () => {
    // Test recording tab
    const recordingTab = page.locator('[role="tab"]:has-text("Aufnehmen")')
    await recordingTab.click()
    await expect(recordingTab).toHaveAttribute('data-state', 'active')
    await expect(page.locator('text=Audio Aufnahme')).toBeVisible()
    
    // Test upload tab
    const uploadTab = page.locator('[role="tab"]:has-text("Hochladen")')
    await uploadTab.click()
    await expect(uploadTab).toHaveAttribute('data-state', 'active')
    await expect(page.locator('text=Audio hochladen')).toBeVisible()
    
    // Test library tab
    const libraryTab = page.locator('[role="tab"]:has-text("Bibliothek")')
    await libraryTab.click()
    await expect(libraryTab).toHaveAttribute('data-state', 'active')
    await expect(page.locator('text=Audio Bibliothek')).toBeVisible()
  })

  test('should support keyboard navigation', async () => {
    // Test tab navigation
    await page.keyboard.press('Tab')
    
    // First tab should be focused
    const firstTab = page.locator('[role="tab"]').first()
    await expect(firstTab).toBeFocused()
    
    // Arrow keys should navigate between tabs
    await page.keyboard.press('ArrowRight')
    const secondTab = page.locator('[role="tab"]').nth(1)
    await expect(secondTab).toBeFocused()
    
    await page.keyboard.press('ArrowLeft')
    await expect(firstTab).toBeFocused()
  })

  test('should be responsive on mobile devices', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 })
    
    // Check that elements are still visible and accessible
    await expect(page.locator('h1:has-text("VOICE CLONE")')).toBeVisible()
    await expect(page.locator('[role="tab"]:has-text("Aufnehmen")')).toBeVisible()
    
    // Check that buttons are large enough for touch
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    const buttonBox = await recordButton.first().boundingBox()
    expect(buttonBox?.width).toBeGreaterThan(44) // Minimum touch target size
    expect(buttonBox?.height).toBeGreaterThan(44)
  })

  test('should maintain state when switching tabs', async () => {
    // Mock recording completion
    await page.addInitScript(() => {
      navigator.mediaDevices.getUserMedia = async () => {
        const stream = new MediaStream()
        const track = { stop: () => {} } as any
        stream.addTrack(track)
        return stream
      }
      
      window.MediaRecorder = class {
        constructor() {}
        start() {
          this.state = 'recording'
          setTimeout(() => {
            if (this.ondataavailable) {
              const blob = new Blob(['audio-data'], { type: 'audio/wav' })
              this.ondataavailable({ data: blob } as any)
            }
            if (this.onstop) this.onstop()
          }, 1000)
        }
        stop() { this.state = 'inactive' }
        state = 'inactive'
        ondataavailable = null
        onstop = null
        onstart = null
      } as any
    })
    
    // Record audio
    const recordButton = page.locator('button:has-text("Aufnahme starten")')
    await recordButton.first().click()
    
    // Wait for recording to complete
    await page.waitForTimeout(1500)
    
    // Switch to library tab
    const libraryTab = page.locator('[role="tab"]:has-text("Bibliothek")')
    await libraryTab.click()
    
    // Check that recording appears in library
    await expect(page.locator('text=Aufnahme')).toBeVisible({ timeout: 2000 })
    
    // Switch back to recording tab
    const recordingTab = page.locator('[role="tab"]:has-text("Aufnehmen")')
    await recordingTab.click()
    
    // Should show proper state (ready for next recording)
    await expect(page.locator('text=1 Aufnahme gespeichert')).toBeVisible()
  })
})