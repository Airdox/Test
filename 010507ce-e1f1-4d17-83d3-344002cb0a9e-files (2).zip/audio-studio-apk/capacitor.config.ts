import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.audiostudio.app',
  appName: 'Audio Studio',
  webDir: 'dist',
  plugins: {
    Camera: {
      permissions: []
    },
    Microphone: {
      permissions: ['microphone']
    }
  },
  android: {
    allowMixedContent: true,
    webContentsDebuggingEnabled: true,
    buildOptions: {
      minSdkVersion: 26,
      compileSdkVersion: 34,
      targetSdkVersion: 34
    }
  }
};

export default config;