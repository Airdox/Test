import { chromium, FullConfig } from '@playwright/test'

async function globalSetup(config: FullConfig) {
  console.log('🚀 Starting global E2E test setup...')
  
  // Launch browser for setup
  const browser = await chromium.launch()
  const context = await browser.newContext({
    permissions: ['microphone']
  })
  const page = await context.newPage()
  
  try {
    // Navigate to the app to ensure it's running
    await page.goto('http://localhost:5173', { waitUntil: 'networkidle' })
    
    // Wait for the app to fully load
    await page.waitForSelector('[data-testid="app-container"]', { timeout: 10000 })
    
    console.log('✅ App is running and ready for tests')
    
    // Setup test data if needed
    await setupTestData(page)
    
  } catch (error) {
    console.error('❌ Global setup failed:', error)
    throw error
  } finally {
    await browser.close()
  }
  
  console.log('✅ Global E2E test setup completed')
}

async function setupTestData(page: any) {
  // Create mock audio files for testing if needed
  console.log('📁 Setting up test data...')
  
  // This could include:
  // - Creating test user accounts
  // - Setting up mock API responses
  // - Preparing test audio files
  // - Initializing test database state
  
  console.log('✅ Test data setup completed')
}

export default globalSetup