import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { screen, waitFor, fireEvent } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { render } from './test/utils'
import App from './App'
import { 
  createMockAudioRecording, 
  createMockFile, 
  createMockDataTransfer,
  mockMediaDevices 
} from './test/test-data'

// Mock navigator.mediaDevices
Object.defineProperty(navigator, 'mediaDevices', {
  writable: true,
  value: mockMediaDevices
})

describe('App Component', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    // Reset URL.createObjectURL mock
    global.URL.createObjectURL = vi.fn().mockReturnValue('mock-object-url')
    global.URL.revokeObjectURL = vi.fn()
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  describe('Initial Render', () => {
    it('renders the main application', () => {
      render(<App />)
      
      expect(screen.getByText('VOICE CLONE')).toBeInTheDocument()
      expect(screen.getByText('STUDIO')).toBeInTheDocument()
      expect(screen.getByText(/Professionelle Audio-Software/)).toBeInTheDocument()
    })

    it('displays all navigation tabs', () => {
      render(<App />)
      
      expect(screen.getByRole('tab', { name: /aufnehmen/i })).toBeInTheDocument()
      expect(screen.getByRole('tab', { name: /hochladen/i })).toBeInTheDocument()
      expect(screen.getByRole('tab', { name: /bibliothek/i })).toBeInTheDocument()
      expect(screen.getByRole('tab', { name: /voice cloning/i })).toBeInTheDocument()
      expect(screen.getByRole('tab', { name: /training/i })).toBeInTheDocument()
    })

    it('has recording tab active by default', () => {
      render(<App />)
      
      const recordingTab = screen.getByRole('tab', { name: /aufnehmen/i })
      expect(recordingTab).toHaveAttribute('data-state', 'active')
    })

    it('displays the record button in initial state', () => {
      render(<App />)
      
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      expect(recordButton).toBeInTheDocument()
      expect(recordButton).not.toBeDisabled()
    })
  })

  describe('Audio Recording', () => {
    it('starts recording when record button is clicked', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      expect(mockMediaDevices.getUserMedia).toHaveBeenCalledWith({ audio: true })
      
      await waitFor(() => {
        expect(screen.getByText(/aufnahme läuft/i)).toBeInTheDocument()
      })
    })

    it('displays recording timer during recording', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      await waitFor(() => {
        expect(screen.getByText(/0:00/)).toBeInTheDocument()
      })
    })

    it('stops recording when stop button is clicked', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Start recording
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      await waitFor(() => {
        expect(screen.getByText(/aufnahme läuft/i)).toBeInTheDocument()
      })
      
      // Stop recording
      const stopButton = screen.getByRole('button', { name: /stoppen/i })
      await user.click(stopButton)
      
      await waitFor(() => {
        expect(screen.queryByText(/aufnahme läuft/i)).not.toBeInTheDocument()
      })
    })

    it('handles microphone access denial gracefully', async () => {
      const user = userEvent.setup()
      mockMediaDevices.getUserMedia.mockRejectedValueOnce(new Error('Permission denied'))
      
      // Mock alert
      const alertSpy = vi.spyOn(window, 'alert').mockImplementation(() => {})
      
      render(<App />)
      
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      await waitFor(() => {
        expect(alertSpy).toHaveBeenCalledWith(
          expect.stringContaining('Mikrofon-Zugriff nicht möglich')
        )
      })
      
      alertSpy.mockRestore()
    })
  })

  describe('File Upload', () => {
    it('switches to upload tab', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      expect(uploadTab).toHaveAttribute('data-state', 'active')
      expect(screen.getByText(/ziehen sie audiodateien hierher/i)).toBeInTheDocument()
    })

    it('handles file selection via input', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Switch to upload tab
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      // Create mock file
      const file = createMockFile('test.wav', 'audio-data', 'audio/wav')
      const input = screen.getByRole('button', { name: /dateien auswählen/i })
        .parentElement?.querySelector('input[type="file"]') as HTMLInputElement
      
      // Simulate file selection
      Object.defineProperty(input, 'files', {
        value: [file],
        writable: false
      })
      
      fireEvent.change(input)
      
      await waitFor(() => {
        expect(screen.getByText('test.wav')).toBeInTheDocument()
      })
    })

    it('handles drag and drop file upload', async () => {
      render(<App />)
      
      // Switch to upload tab
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await userEvent.click(uploadTab)
      
      const dropZone = screen.getByText(/ziehen sie audiodateien hierher/i).closest('div')!
      const file = createMockFile('dropped.mp3', 'audio-data', 'audio/mp3')
      const dataTransfer = createMockDataTransfer([file])
      
      // Simulate drag over
      fireEvent.dragOver(dropZone, { dataTransfer })
      expect(dropZone).toHaveClass(/border-primary/)
      
      // Simulate drop
      fireEvent.drop(dropZone, { dataTransfer })
      
      await waitFor(() => {
        expect(screen.getByText('dropped.mp3')).toBeInTheDocument()
      })
    })

    it('rejects non-audio files', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Switch to upload tab
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      const dropZone = screen.getByText(/ziehen sie audiodateien hierher/i).closest('div')!
      const file = createMockFile('document.pdf', 'pdf-data', 'application/pdf')
      const dataTransfer = createMockDataTransfer([file])
      
      fireEvent.drop(dropZone, { dataTransfer })
      
      // Should not add non-audio files
      await waitFor(() => {
        expect(screen.queryByText('document.pdf')).not.toBeInTheDocument()
      })
    })
  })

  describe('Audio Library', () => {
    it('switches to library tab', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const libraryTab = screen.getByRole('tab', { name: /bibliothek/i })
      await user.click(libraryTab)
      
      expect(libraryTab).toHaveAttribute('data-state', 'active')
      expect(screen.getByText(/noch keine audiodateien vorhanden/i)).toBeInTheDocument()
    })

    it('displays recordings in library after recording', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Record audio first
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      await waitFor(() => {
        expect(screen.getByText(/aufnahme läuft/i)).toBeInTheDocument()
      })
      
      const stopButton = screen.getByRole('button', { name: /stoppen/i })
      await user.click(stopButton)
      
      // Wait for recording to be saved
      await waitFor(() => {
        expect(screen.queryByText(/aufnahme läuft/i)).not.toBeInTheDocument()
      })
      
      // Switch to library
      const libraryTab = screen.getByRole('tab', { name: /bibliothek/i })
      await user.click(libraryTab)
      
      // Should show the recording
      await waitFor(() => {
        expect(screen.getByText(/aufnahme \d+:\d+:\d+/)).toBeInTheDocument()
      })
    })

    it('plays audio when play button is clicked', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Add a mock recording first by uploading a file
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      const file = createMockFile('test.wav', 'audio-data', 'audio/wav')
      const input = screen.getByRole('button', { name: /dateien auswählen/i })
        .parentElement?.querySelector('input[type="file"]') as HTMLInputElement
      
      Object.defineProperty(input, 'files', {
        value: [file],
        writable: false
      })
      fireEvent.change(input)
      
      // Switch to library
      const libraryTab = screen.getByRole('tab', { name: /bibliothek/i })
      await user.click(libraryTab)
      
      await waitFor(() => {
        expect(screen.getByText('test.wav')).toBeInTheDocument()
      })
      
      // Click play button
      const playButton = screen.getByRole('button', { name: /play/i })
      await user.click(playButton)
      
      // Should change to pause button
      await waitFor(() => {
        expect(screen.getByRole('button', { name: /pause/i })).toBeInTheDocument()
      })
    })

    it('downloads recording when download button is clicked', async () => {
      const user = userEvent.setup()
      
      // Mock document.createElement and appendChild
      const mockLink = {
        href: '',
        download: '',
        click: vi.fn()
      }
      const createElementSpy = vi.spyOn(document, 'createElement').mockReturnValue(mockLink as any)
      const appendChildSpy = vi.spyOn(document.body, 'appendChild').mockImplementation(() => mockLink as any)
      const removeChildSpy = vi.spyOn(document.body, 'removeChild').mockImplementation(() => mockLink as any)
      
      render(<App />)
      
      // Add a mock recording
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      const file = createMockFile('test.wav', 'audio-data', 'audio/wav')
      const input = screen.getByRole('button', { name: /dateien auswählen/i })
        .parentElement?.querySelector('input[type="file"]') as HTMLInputElement
      
      Object.defineProperty(input, 'files', {
        value: [file],
        writable: false
      })
      fireEvent.change(input)
      
      // Switch to library
      const libraryTab = screen.getByRole('tab', { name: /bibliothek/i })
      await user.click(libraryTab)
      
      await waitFor(() => {
        expect(screen.getByText('test.wav')).toBeInTheDocument()
      })
      
      // Click download button
      const downloadButton = screen.getByRole('button', { name: /download/i })
      await user.click(downloadButton)
      
      expect(createElementSpy).toHaveBeenCalledWith('a')
      expect(mockLink.click).toHaveBeenCalled()
      
      createElementSpy.mockRestore()
      appendChildSpy.mockRestore()
      removeChildSpy.mockRestore()
    })

    it('deletes recording when delete button is clicked', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Add a mock recording
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      const file = createMockFile('test.wav', 'audio-data', 'audio/wav')
      const input = screen.getByRole('button', { name: /dateien auswählen/i })
        .parentElement?.querySelector('input[type="file"]') as HTMLInputElement
      
      Object.defineProperty(input, 'files', {
        value: [file],
        writable: false
      })
      fireEvent.change(input)
      
      // Switch to library
      const libraryTab = screen.getByRole('tab', { name: /bibliothek/i })
      await user.click(libraryTab)
      
      await waitFor(() => {
        expect(screen.getByText('test.wav')).toBeInTheDocument()
      })
      
      // Click delete button
      const deleteButton = screen.getByRole('button', { name: /trash/i })
      await user.click(deleteButton)
      
      // Recording should be removed
      await waitFor(() => {
        expect(screen.queryByText('test.wav')).not.toBeInTheDocument()
        expect(screen.getByText(/noch keine audiodateien vorhanden/i)).toBeInTheDocument()
      })
    })
  })

  describe('Voice Cloning Tab', () => {
    it('switches to voice cloning tab', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const voiceTab = screen.getByRole('tab', { name: /voice cloning/i })
      await user.click(voiceTab)
      
      expect(voiceTab).toHaveAttribute('data-state', 'active')
      expect(screen.getByText(/stimme klonen/i)).toBeInTheDocument()
    })
  })

  describe('Training Tab', () => {
    it('switches to training tab', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const trainingTab = screen.getByRole('tab', { name: /training/i })
      await user.click(trainingTab)
      
      expect(trainingTab).toHaveAttribute('data-state', 'active')
      expect(screen.getByText(/modell training/i)).toBeInTheDocument()
    })
  })

  describe('Keyboard Navigation', () => {
    it('supports tab navigation between elements', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Tab should navigate through interactive elements
      await user.tab()
      expect(screen.getByRole('tab', { name: /aufnehmen/i })).toHaveFocus()
      
      await user.tab()
      expect(screen.getByRole('tab', { name: /hochladen/i })).toHaveFocus()
      
      await user.tab()
      expect(screen.getByRole('tab', { name: /bibliothek/i })).toHaveFocus()
    })

    it('supports arrow key navigation in tab list', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      // Focus first tab
      const firstTab = screen.getByRole('tab', { name: /aufnehmen/i })
      firstTab.focus()
      
      // Arrow right should move to next tab
      await user.keyboard('{ArrowRight}')
      expect(screen.getByRole('tab', { name: /hochladen/i })).toHaveFocus()
      
      // Arrow left should move back
      await user.keyboard('{ArrowLeft}')
      expect(screen.getByRole('tab', { name: /aufnehmen/i })).toHaveFocus()
    })
  })

  describe('Error Handling', () => {
    it('handles empty recordings gracefully', async () => {
      const user = userEvent.setup()
      
      // Mock MediaRecorder to not provide any data
      const mockMediaRecorder = vi.fn().mockImplementation(() => ({
        start: vi.fn(),
        stop: vi.fn(),
        state: 'inactive',
        ondataavailable: null,
        onstop: null
      }))
      global.MediaRecorder = mockMediaRecorder as any
      
      render(<App />)
      
      const recordButton = screen.getByRole('button', { name: /aufnahme starten/i })
      await user.click(recordButton)
      
      // Should handle the case gracefully without crashing
      expect(screen.getByText(/bereit für die erste aufnahme/i)).toBeInTheDocument()
    })

    it('handles invalid audio files', async () => {
      const user = userEvent.setup()
      render(<App />)
      
      const uploadTab = screen.getByRole('tab', { name: /hochladen/i })
      await user.click(uploadTab)
      
      // Try to upload an invalid file
      const invalidFile = new File(['invalid'], 'invalid.txt', { type: 'text/plain' })
      const input = screen.getByRole('button', { name: /dateien auswählen/i })
        .parentElement?.querySelector('input[type="file"]') as HTMLInputElement
      
      Object.defineProperty(input, 'files', {
        value: [invalidFile],
        writable: false
      })
      
      fireEvent.change(input)
      
      // Should not crash and should not add the file
      await waitFor(() => {
        expect(screen.queryByText('invalid.txt')).not.toBeInTheDocument()
      })
    })
  })

  describe('Responsive Design', () => {
    it('adapts to mobile viewport', () => {
      // Mock window.innerWidth
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 375
      })
      
      render(<App />)
      
      // Should still render correctly on mobile
      expect(screen.getByText('VOICE CLONE')).toBeInTheDocument()
      expect(screen.getByRole('tab', { name: /aufnehmen/i })).toBeInTheDocument()
    })
  })
})